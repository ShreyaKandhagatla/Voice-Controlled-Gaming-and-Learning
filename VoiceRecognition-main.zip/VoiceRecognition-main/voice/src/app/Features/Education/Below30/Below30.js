import React from "react";

import InterviewPrep from './components/InterviewPrep';



function App() {
  return (
    <div className="App">
      <InterviewPrep />
    </div>
  );
}
export default App;

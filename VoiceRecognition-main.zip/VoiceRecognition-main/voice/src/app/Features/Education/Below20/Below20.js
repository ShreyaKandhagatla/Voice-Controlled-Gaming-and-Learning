/*import React from "react";

function Below20() {
  return (
    <div className="bg-black text-white min-h-screen flex items-center justify-center">
      <h1 className="text-4xl font-bold">Hi, develop a below 20 game</h1>
    </div>
  );
}

export default Below20;
*/
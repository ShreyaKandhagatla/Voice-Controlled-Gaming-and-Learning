// app/Features/Chatbot.js
import React from "react";

function Chatbot() {
  return (
    <div className="bg-black text-white min-h-screen flex items-center justify-center">
      <h1 className="text-4xl font-bold">Hi, I am a chatbot</h1>
    </div>
  );
}

export default Chatbot;
